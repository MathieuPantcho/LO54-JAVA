
# *************************************************************************
# ***              NE TOUCHEZ PAS AUX FICHIERS DE CE REPERTOIRE !                ***
# *** LES FICHIERS DE CE REPERTOIRE ET SES SOUS-REPERTOIRES CONSTITUENT     ***
# *** UNE BASE DE DONNEES DERBY, QUI CONTIENT LES DONNEES (UTILISATEUR ET SYSTEME)       ***
# *** ET LES FICHIERS NECESSAIRES POUR LA RECUPERATION DE LA BASE DE DONNEES.                            ***
# *** TOUTE MODIFICATION, TOUT AJOUT OU TOUTE SUPPRESSION DE L'UN DE CES FICHIERS PEUT ENTRAINER    ***
# *** UNE ALTERATION DES DONNEES ET RISQUE DE LAISSER LA BASE DE DONNEES DANS UN ETAT IRRECUPERABLE.     ***
# *************************************************************************